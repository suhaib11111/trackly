// Trackly tracker firmware – ESP32 + GPS + MPU6050 + OLED
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_SSD1306.h>
#include <Wire.h>

const char* SUPABASE_URL = "https://lcrvuijwpvhphbuwxtny.supabase.co/rest/v1/rpc/report_location";
const char* SUPABASE_KEY = "sb_publishable_pW_dqVXVi9PMOH8FjPpa6g_VI_GQ2rF";
const char* DEVICE_CODE  = "SB-0001";
const char* DEVICE_SECRET = "23b9054a3fb229ee0e7b2159";

const int BATTERY_PIN = 34;   // potentiometer = fake battery
const int BUZZER_PIN  = 13;
const int LOW_BATTERY = 20;   // percent

// GPS: true = fake data in Wokwi, false = real NEO-6M module
const bool SIMULATE_GPS = true;
const int GPS_RX = 16;   // ESP32 pin that receives from GPS TX
const int GPS_TX = 17;   // ESP32 pin that sends to GPS RX
const char* FAKE_NMEA =
  "$GPGGA,120000.00,3611.46600,N,04400.55200,E,1,08,0.9,415.0,M,0.0,M,,*5D\r\n"
  "$GPRMC,120000.00,A,3611.46600,N,04400.55200,E,0.5,0.0,191026,,,A*56\r\n";

Adafruit_MPU6050 mpu;
Adafruit_SSD1306 display(128, 64, &Wire, -1);

// ---- simple GPS reader (no library needed) ----
struct GpsFix {
  bool valid = false;
  double lat = 0;
  double lng = 0;
  int sats = 0;
};
GpsFix gpsFix;
String nmeaLine = "";

// "3611.46600" + "N" -> 36.191100
double nmeaToDegrees(const String& value, const String& hemi) {
  if (value.length() == 0) return 0;
  double v = atof(value.c_str());
  int deg = (int)(v / 100);
  double minutes = v - deg * 100;
  double result = deg + minutes / 60.0;
  if (hemi == "S" || hemi == "W") result = -result;
  return result;
}

void parseNmea(const String& line) {
  // We only need GGA sentences: $GPGGA or $GNGGA
  if (!(line.startsWith("$GPGGA") || line.startsWith("$GNGGA"))) return;

  String fields[15];
  int count = 0, start = 0;
  for (int i = 0; i <= (int)line.length() && count < 15; i++) {
    if (i == (int)line.length() || line[i] == ',' || line[i] == '*') {
      fields[count++] = line.substring(start, i);
      start = i + 1;
    }
  }
  if (count < 8) return;

  int quality = fields[6].toInt();   // 0 = no fix
  if (quality > 0 && fields[2].length() > 0 && fields[4].length() > 0) {
    gpsFix.lat = nmeaToDegrees(fields[2], fields[3]);
    gpsFix.lng = nmeaToDegrees(fields[4], fields[5]);
    gpsFix.sats = fields[7].toInt();
    gpsFix.valid = true;
  } else {
    gpsFix.valid = false;
  }
}

void feedGps(char c) {
  if (c == '\n') {
    parseNmea(nmeaLine);
    nmeaLine = "";
  } else if (c != '\r') {
    nmeaLine += c;
    if (nmeaLine.length() > 120) nmeaLine = "";  // safety
  }
}

void readGPS() {
  if (SIMULATE_GPS) {
    for (const char* p = FAKE_NMEA; *p; p++) feedGps(*p);
  } else {
    while (Serial2.available()) feedGps(Serial2.read());
  }
}

// ---- tracker state ----
unsigned long lastSend = 0;
unsigned long interval = 60000;            // normal mode: 1 minute
const unsigned long LIVE_INTERVAL = 5000;  // lost mode: 5 seconds
String mode = "normal";
bool lowWarned = false;
int lastShown = -1;

int readBattery() {
  int raw = analogRead(BATTERY_PIN);
  return map(raw, 0, 4095, 0, 100);
}

void beep(int times) {
  for (int i = 0; i < times; i++) {
    tone(BUZZER_PIN, 2000);
    delay(150);
    noTone(BUZZER_PIN);
    delay(150);
  }
}

void showScreen(int battery, bool moving) {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  display.setTextSize(2);
  display.setCursor(0, 0);
  display.print("Bat: ");
  display.print(battery);
  display.println("%");

  display.setTextSize(1);
  display.setCursor(0, 20);
  display.print("Mode: ");
  display.println(mode);
  display.print("Bag: ");
  display.println(moving ? "MOVING" : "still");
  display.print("WiFi: ");
  display.println(WiFi.status() == WL_CONNECTED ? "OK" : "off");
  display.print("GPS: ");
  if (gpsFix.valid) {
    display.print("fix, ");
    display.print(gpsFix.sats);
    display.println(" sats");
  } else {
    display.println("searching...");
  }

  display.display();
}

void setup() {
  Serial.begin(115200);
  pinMode(BUZZER_PIN, OUTPUT);
  Wire.begin(21, 22);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("Screen not found!");
  }
  display.clearDisplay();
  display.setTextSize(2);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Trackly");
  display.setTextSize(1);
  display.println("Starting...");
  display.display();

  if (!mpu.begin()) { Serial.println("Sensor not found!"); while (true); }

  if (!SIMULATE_GPS) {
    Serial2.begin(9600, SERIAL_8N1, GPS_RX, GPS_TX);
  }

  WiFi.begin("Wokwi-GUEST", "");
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) { delay(300); Serial.print("."); }
  Serial.println(" connected!");
}

void sendLocation(double lat, double lng, int battery) {
  WiFiClientSecure client;
  client.setInsecure();  // OK for testing only
  HTTPClient http;
  http.begin(client, SUPABASE_URL);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("apikey", SUPABASE_KEY);

  String body = "{\"p_code\":\"" + String(DEVICE_CODE) + "\",\"p_secret\":\"" + String(DEVICE_SECRET) +
                "\",\"p_lat\":" + String(lat, 6) + ",\"p_lng\":" + String(lng, 6) +
                ",\"p_battery\":" + String(battery) + "}";

  int code = http.POST(body);
  String reply = http.getString();
  Serial.printf("Sent %.6f, %.6f, battery %d%% -> HTTP %d, reply: %s\n",
                lat, lng, battery, code, reply.c_str());

  if (code == 200) {
    mode = reply.indexOf("lost") >= 0 ? "lost" : "normal";
  }
  http.end();
}

void loop() {
  readGPS();

  // Battery
  int battery = readBattery();

  if (abs(battery - lastShown) >= 5) {
    Serial.printf("Battery: %d%%\n", battery);
    if (battery >= 99) Serial.println("Fully charged!");
    lastShown = battery;
  }

  if (battery <= LOW_BATTERY && !lowWarned) {
    Serial.println("LOW BATTERY!");
    if (mode != "lost") beep(3);   // stay silent if stolen
    lowWarned = true;
  }
  if (battery > LOW_BATTERY + 5) lowWarned = false;

  // Motion
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);
  float total = abs(a.acceleration.x) + abs(a.acceleration.y) + abs(a.acceleration.z - 9.8);
  bool moving = total > 2;

  showScreen(battery, moving);

  // Send location
  unsigned long wait = (mode == "lost") ? LIVE_INTERVAL : interval;

  if ((moving || mode == "lost") && millis() - lastSend > wait) {
    if (gpsFix.valid) {
      sendLocation(gpsFix.lat, gpsFix.lng, battery);
    } else {
      Serial.println("No GPS fix yet, skipping send");
    }
    lastSend = millis();
  }
  delay(200);
}